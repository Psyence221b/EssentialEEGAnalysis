function yticklabel(labels)

set(gca,'yticklabel',labels)

